package com.joaocampos.projetoloja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetolojaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetolojaApplication.class, args);
	}

}
