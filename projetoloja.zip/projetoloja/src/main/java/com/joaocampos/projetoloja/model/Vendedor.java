package com.joaocampos.projetoloja.model;

public class Vendedor {
    private int codigodeid;
    
    private String nome;
    
    private int senha;

    
    public int getCodigodeid() {
        return codigodeid;
    }
    public void setCodigodeid(int codigodeid) {
        this.codigodeid = codigodeid;
    }

    public String getnome() {
        return nome;
    }
    public void setnome(String nome) {
        nome = nome;
    }

    public int getSenha() {
        return senha;
    }
    public void setSenha(int senha) {
        this.senha = senha;
    }


}
