package com.joaocampos.projetoloja.model;

import java.time.LocalDate;

public class Venda {
    private int codigo;  
    private LocalDate datadaVenda;
   
    
    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public LocalDate getDatadaVenda() {
        return datadaVenda;
    }
    public void setDatadaVenda(LocalDate datadaVenda) {
        this.datadaVenda = datadaVenda;
    }

}
