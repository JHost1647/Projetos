package com.joaocampos.projetoloja.service;

import java.util.List;

import com.joaocampos.projetoloja.model.Produto;

public class ProdutoService {

    public List<Produto> findAll() {
        return null;
    }

    public Object save(Produto produto) {
        return null;
    }

    public Object delete(Produto produto) {
        return null;
    }
    
}
