package com.joaocampos.projetoloja.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joaocampos.projetoloja.model.Produto;
import com.joaocampos.projetoloja.service.ProdutoService;

@RestController
@RequestMapping("/api/Produto")
public class ProdutoController {
    
    @Autowired
    private ProdutoService service;


    @GetMapping
    public List<Produto> findAll() {
        return service.findAll();
    }

    @PostMapping
    public ResponseEntity<Object> save(@RequestBody Produto produto) {
        try{
            return new ResponseEntity<>(service.save(produto), HttpStatus.CREATED);
        } catch (Exception e) {
            
                return new ResponseEntity<Object>("Lamento, houve um erro na Aplicação", HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }       

    @PutMapping
    public ResponseEntity<Object> edit(@RequestBody Produto produto) {
        try{
            return new ResponseEntity<>(service.save(produto), HttpStatus.CREATED);

        } catch (Exception e) {
            return new ResponseEntity<>("Lamento, houve um erro inesperado na Aplicação", HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }

    @DeleteMapping
    public ResponseEntity<Object> delete (@RequestBody Produto produto) {
        try{
            return new ResponseEntity<>(service.delete(produto),HttpStatus.OK);
        }catch(IllegalArgumentException ia) {
            return new ResponseEntity<>(ia.getMessage(),HttpStatus.BAD_REQUEST);
        }catch (Exception e) {
            return new ResponseEntity<>("Lamento, houve um erro inesperado em nosso sistema, tente novamente mais tarde!!!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}







    

   


   





