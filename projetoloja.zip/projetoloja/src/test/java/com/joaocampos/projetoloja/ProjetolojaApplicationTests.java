package com.joaocampos.projetoloja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetolojaApplicationTests {

	@Test
	void contextLoads() {
	}

}
