package com.joaocampos.projetoloja.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.joaocampos.projetoloja.model.Produto;
import com.joaocampos.projetoloja.repository.ProdutoRepository;

@Service
public class ProdutoService {
    @Autowired
    private ProdutoRepository repository;

    public List<Produto> findAll() {
        return repository.findAll();
    }

    public Object save(Produto produto) {
        return repository.save(produto);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    public Optional<Produto> findById(Long isbn) {
        return repository.findById(isbn);
    }
  
}