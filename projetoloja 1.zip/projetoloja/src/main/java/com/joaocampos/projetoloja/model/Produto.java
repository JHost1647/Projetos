package com.joaocampos.projetoloja.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Produto")
public class Produto {
    @Id
    private Long sku;    
    private float preco;   
    private String tamanho;   
    private String cor;
    private String tipoderoupa;
    
    
    public Long getSku() {
        return sku;
    }
    public void setSku(Long sku) {
        this.sku = sku;
    }

    public float getPreco() {
        return preco;
    }
    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getTamanho() {
        return tamanho;
    }
    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getCor() {
        return cor;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getTipoderoupa() {
        return tipoderoupa;
    }
    public void setTipoderoupa(String tipoderoupa) {
        this.tipoderoupa = tipoderoupa;
    }

}
