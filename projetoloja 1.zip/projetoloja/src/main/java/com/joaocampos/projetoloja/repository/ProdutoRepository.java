package com.joaocampos.projetoloja.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.joaocampos.projetoloja.model.Produto;


@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    
}


/*
public class ToDoRepository {
    private static List<ToDo> tasks = new ArrayList<>();

    public List<ToDo> findAll(){
        return tasks;
    }

    public ToDo save(ToDo todo){
       tasks.add(todo);
       return todo;
    }

    public ToDo edit(ToDo todo) {
        for (int i = 0; i < tasks.size(); i++) {
            ToDo element = tasks.get(i);
            if(element.getDescription().equals(todo.getDescription())) {
                tasks.set(i, todo);
                break;
            }
        }
        return todo;
    }

    public ToDo delete(ToDo todo) {
        for(int i=0; i < tasks.size(); i++) {
            ToDo element = tasks.get(i);
            if (element.getDescription().equals(todo.getDescription())) {
                tasks.remove(i);
                break;
            } 
        }
        return todo;
    }
}
*/