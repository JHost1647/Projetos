package com.joaocampos.projetoloja.model;

import jakarta.persistence.Id;

public class Vendedor {
    @Id
    private Long codigodeid;
    
    private String nome;
    
    private int senha;

    
    public Long getCodigodeid() {
        return codigodeid;
    }
    public void setCodigodeid(Long codigodeid) {
        this.codigodeid = codigodeid;
    }

    public String getnome() {
        return nome;
    }
    public void setnome(String nome) {
        nome = nome;
    }

    public int getSenha() {
        return senha;
    }
    public void setSenha(int senha) {
        this.senha = senha;
    }


}
