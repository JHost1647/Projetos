package com.joaocampos.projetoloja.model;

import java.time.LocalDate;

import jakarta.persistence.Id;

public class Venda {
    @Id
    private Long codigo;  
    private LocalDate datadaVenda;
   
    
    public Long getCodigo() {
        return codigo;
    }
    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public LocalDate getDatadaVenda() {
        return datadaVenda;
    }
    public void setDatadaVenda(LocalDate datadaVenda) {
        this.datadaVenda = datadaVenda;
    }

}
